import { GradeCalculator } from '@/components/GradeCalculator';

function App() {
  return <GradeCalculator />;
}

export default App;
