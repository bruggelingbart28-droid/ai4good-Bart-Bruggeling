import type { GradeEntry, CalcResult } from './types';

interface ParsedData {
  validEntries: { grade: number; weight: number }[];
  currentWeightedTotal: number;
  currentTotalWeight: number;
  currentAverage: number | null;
}

export function parseGrades(entries: GradeEntry[]): ParsedData {
  const validEntries = entries
    .map((e) => ({
      grade: parseFloat(e.grade),
      weight: parseFloat(e.weight),
    }))
    .filter(
      (e) =>
        !isNaN(e.grade) &&
        !isNaN(e.weight) &&
        e.grade >= 0 &&
        e.grade <= 10 &&
        e.weight > 0
    );

  const currentWeightedTotal = validEntries.reduce(
    (sum, e) => sum + e.grade * e.weight,
    0
  );
  const currentTotalWeight = validEntries.reduce(
    (sum, e) => sum + e.weight,
    0
  );
  const currentAverage =
    currentTotalWeight > 0 ? currentWeightedTotal / currentTotalWeight : null;

  return {
    validEntries,
    currentWeightedTotal,
    currentTotalWeight,
    currentAverage,
  };
}

export function calculate(
  entries: GradeEntry[],
  targetStr: string,
  remainingStr: string
): CalcResult {
  const {
    validEntries,
    currentWeightedTotal,
    currentTotalWeight,
    currentAverage,
  } = parseGrades(entries);

  const target = parseFloat(targetStr);
  const remaining = parseFloat(remainingStr);

  const hasGrades = validEntries.length > 0;
  const hasTarget = !isNaN(target) && target >= 0 && target <= 10;
  const hasRemaining = !isNaN(remaining) && remaining > 0;

  const base: CalcResult = {
    status: 'empty',
    requiredGrade: null,
    maxFinalGrade: null,
    minFinalGrade: null,
    currentAverage,
    currentTotalWeight,
    remainingWeight: hasRemaining ? remaining : 0,
    target: hasTarget ? target : null,
    hasGrades,
    hasTarget,
    hasRemaining,
  };

  if (!hasGrades && !hasRemaining) {
    return base;
  }

  if (!hasTarget) {
    return base;
  }

  if (!hasRemaining) {
    if (currentAverage !== null && currentAverage >= target) {
      return {
        ...base,
        status: 'already-there',
        minFinalGrade: currentAverage,
        maxFinalGrade: currentAverage,
      };
    }
    return { ...base, status: 'need-remaining' };
  }

  const totalWeight = currentTotalWeight + remaining;
  const requiredGrade =
    (target * totalWeight - currentWeightedTotal) / remaining;
  const maxFinalGrade = (currentWeightedTotal + 10 * remaining) / totalWeight;
  const minFinalGrade = currentWeightedTotal / totalWeight;

  if (requiredGrade <= 0) {
    return {
      ...base,
      status: 'already-there',
      requiredGrade,
      maxFinalGrade,
      minFinalGrade,
    };
  }

  if (requiredGrade > 10) {
    return {
      ...base,
      status: 'impossible',
      requiredGrade,
      maxFinalGrade,
      minFinalGrade,
    };
  }

  return {
    ...base,
    status: 'possible',
    requiredGrade,
    maxFinalGrade,
    minFinalGrade,
  };
}

export function formatGrade(value: number): string {
  return value.toFixed(2);
}
