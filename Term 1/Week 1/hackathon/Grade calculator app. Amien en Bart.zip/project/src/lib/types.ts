export interface GradeEntry {
  id: string;
  grade: string;
  weight: string;
}

export type ResultStatus =
  | 'empty'
  | 'possible'
  | 'impossible'
  | 'already-there'
  | 'need-remaining';

export interface CalcResult {
  status: ResultStatus;
  requiredGrade: number | null;
  maxFinalGrade: number | null;
  minFinalGrade: number | null;
  currentAverage: number | null;
  currentTotalWeight: number;
  remainingWeight: number;
  target: number | null;
  hasGrades: boolean;
  hasTarget: boolean;
  hasRemaining: boolean;
}
