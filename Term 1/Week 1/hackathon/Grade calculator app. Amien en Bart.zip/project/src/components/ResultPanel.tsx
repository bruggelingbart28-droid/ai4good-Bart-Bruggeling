import { CheckCircle2, AlertTriangle, Target, Info } from 'lucide-react';
import type { CalcResult } from '@/lib/types';
import { formatGrade } from '@/lib/calculations';

interface ResultPanelProps {
  result: CalcResult;
}

export function ResultPanel({ result }: ResultPanelProps) {
  const { status, requiredGrade, maxFinalGrade, minFinalGrade, target } =
    result;

  if (status === 'empty') {
    return (
      <div className="animate-result rounded-2xl bg-navy-500/10 border border-navy-500/15 p-6 sm:p-8 text-center">
        <Info className="mx-auto mb-3 text-cream-100/60" size={28} />
        <p className="text-cream-100/90 text-lg font-medium">
          Enter your grades and weights to see what you need.
        </p>
      </div>
    );
  }

  if (status === 'need-remaining') {
    return (
      <div className="animate-result rounded-2xl bg-navy-500/10 border border-navy-500/15 p-6 sm:p-8 text-center">
        <Target className="mx-auto mb-3 text-cream-100/60" size={28} />
        <p className="text-cream-100/90 text-lg">
          Add the weight of your remaining assessment to see what grade you
          need.
        </p>
      </div>
    );
  }

  if (status === 'already-there') {
    return (
      <div className="animate-result rounded-2xl bg-green-900/25 border border-green-400/30 p-6 sm:p-8 text-center">
        <CheckCircle2 className="mx-auto mb-3 text-green-300" size={32} />
        <h3 className="text-cream-50 font-display text-2xl font-bold mb-2">
          You're already there!
        </h3>
        <p className="text-cream-100/90">
          Your current grades are already enough to reach your target of{' '}
          <strong className="text-cream-50">
            {formatGrade(target!)}
          </strong>
          .
        </p>
        {minFinalGrade !== null && (
          <p className="text-cream-100/80 mt-2">
            A remaining grade of{' '}
            <strong className="text-cream-50">0.00</strong> would still result
            in a final grade of{' '}
            <strong className="text-cream-50">
              {formatGrade(minFinalGrade)}
            </strong>
            .
          </p>
        )}
      </div>
    );
  }

  if (status === 'impossible') {
    return (
      <div className="animate-result rounded-2xl bg-red-950/30 border border-amber-400/30 p-6 sm:p-8 text-center">
        <AlertTriangle className="mx-auto mb-3 text-amber-300" size={32} />
        <h3 className="text-cream-50 font-display text-2xl font-bold mb-2">
          Not possible
        </h3>
        <p className="text-cream-100/90">
          You would need{' '}
          <strong className="text-cream-50">
            {formatGrade(requiredGrade!)}
          </strong>{' '}
          on your remaining assessment to reach{' '}
          <strong className="text-cream-50">{formatGrade(target!)}</strong>.
        </p>
        {maxFinalGrade !== null && (
          <p className="text-cream-100/80 mt-2">
            The highest possible final grade with a{' '}
            <strong className="text-cream-50">10.00</strong> would be:{' '}
            <strong className="text-cream-50">
              {formatGrade(maxFinalGrade)}
            </strong>
            .
          </p>
        )}
      </div>
    );
  }

  return (
    <div className="animate-result rounded-2xl bg-navy-500/15 border border-navy-500/20 p-6 sm:p-8 text-center">
      <p className="text-cream-100/70 text-sm uppercase tracking-wider font-semibold mb-2">
        You need
      </p>
      <p className="font-display text-5xl sm:text-6xl font-bold text-cream-50 leading-none mb-3 drop-shadow-sm">
        {formatGrade(requiredGrade!)}
      </p>
      <p className="text-cream-100/90 text-base sm:text-lg">
        on your remaining assessment
      </p>
      <p className="text-cream-100/70 mt-1">
        to finish with a{' '}
        <strong className="text-cream-50">{formatGrade(target!)}</strong>
      </p>
    </div>
  );
}
