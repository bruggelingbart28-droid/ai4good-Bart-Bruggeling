import { Trash2 } from 'lucide-react';

interface GradeRowProps {
  grade: string;
  weight: string;
  onChange: (field: 'grade' | 'weight', value: string) => void;
  onRemove: () => void;
  canRemove: boolean;
}

function getGradeError(value: string): string | null {
  if (value === '') return null;
  const num = parseFloat(value);
  if (isNaN(num)) return 'Enter a valid number';
  if (num < 0) return "Grade can't be negative";
  if (num > 10) return "Grade can't be above 10";
  return null;
}

function getWeightError(value: string): string | null {
  if (value === '') return null;
  const num = parseFloat(value);
  if (isNaN(num)) return 'Enter a valid number';
  if (num === 0) return "Weight can't be zero";
  if (num < 0) return "Weight can't be negative";
  return null;
}

export function GradeRow({
  grade,
  weight,
  onChange,
  onRemove,
  canRemove,
}: GradeRowProps) {
  const gradeError = getGradeError(grade);
  const weightError = getWeightError(weight);

  return (
    <div className="animate-fade-in bg-cream-50 rounded-xl p-3 sm:p-4 shadow-sm">
      <div className="flex flex-col sm:flex-row gap-3 sm:gap-4 sm:items-start">
        <div className="flex-1">
          <label className="block text-sm font-medium text-navy-500 mb-1">
            Grade
          </label>
          <input
            type="number"
            inputMode="decimal"
            step="0.01"
            min="0"
            max="10"
            placeholder="e.g. 6.5"
            value={grade}
            onChange={(e) => onChange('grade', e.target.value)}
            className={`w-full rounded-lg border bg-white px-3 py-2.5 text-navy-700 text-lg font-medium focus:outline-none transition-colors ${
              gradeError
                ? 'border-red-400 focus:border-red-500 focus:ring-2 focus:ring-red-500/20'
                : 'border-beige-200 focus:border-brown-500 focus:ring-2 focus:ring-brown-500/20'
            }`}
            aria-label="Grade"
            aria-invalid={gradeError !== null}
          />
          <p className="mt-1 text-xs text-navy-500/60">What did you get?</p>
          {gradeError && (
            <p className="mt-1 text-xs text-red-700" role="alert">
              {gradeError}
            </p>
          )}
        </div>

        <div className="flex-1">
          <label className="block text-sm font-medium text-navy-500 mb-1">
            Weight
          </label>
          <input
            type="number"
            inputMode="decimal"
            step="0.5"
            min="0"
            placeholder="e.g. 1"
            value={weight}
            onChange={(e) => onChange('weight', e.target.value)}
            className={`w-full rounded-lg border bg-white px-3 py-2.5 text-navy-700 text-lg font-medium focus:outline-none transition-colors ${
              weightError
                ? 'border-red-400 focus:border-red-500 focus:ring-2 focus:ring-red-500/20'
                : 'border-beige-200 focus:border-brown-500 focus:ring-2 focus:ring-brown-500/20'
            }`}
            aria-label="Weight"
            aria-invalid={weightError !== null}
          />
          <p className="mt-1 text-xs text-navy-500/60">
            How many times does it count?
          </p>
          {weightError && (
            <p className="mt-1 text-xs text-red-700" role="alert">
              {weightError}
            </p>
          )}
        </div>

        <button
          onClick={onRemove}
          disabled={!canRemove}
          className="self-end sm:self-start rounded-lg p-2.5 text-navy-500/40 hover:text-red-700 hover:bg-red-50 disabled:opacity-30 disabled:cursor-not-allowed disabled:hover:text-navy-500/40 disabled:hover:bg-transparent transition-colors focus:outline-none focus:ring-2 focus:ring-red-500/20"
          aria-label="Remove this grade"
          title="Remove this grade"
        >
          <Trash2 size={18} />
        </button>
      </div>
    </div>
  );
}
