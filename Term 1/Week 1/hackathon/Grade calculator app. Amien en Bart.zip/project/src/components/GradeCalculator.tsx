import { useState, useCallback } from 'react';
import { Plus, RotateCcw, Check, X } from 'lucide-react';
import type { GradeEntry } from '@/lib/types';
import { calculate } from '@/lib/calculations';
import { BackgroundNumbers } from './BackgroundNumbers';
import { GradeRow } from './GradeRow';
import { ResultPanel } from './ResultPanel';
import { StatsPanel } from './StatsPanel';

let idCounter = 0;
const generateId = () => `grade-${++idCounter}`;

const createEmptyRow = (): GradeEntry => ({
  id: generateId(),
  grade: '',
  weight: '',
});

const INITIAL_GRADES: GradeEntry[] = [createEmptyRow(), createEmptyRow()];

function getTargetError(value: string): string | null {
  if (value === '') return null;
  const num = parseFloat(value);
  if (isNaN(num)) return 'Enter a valid number';
  if (num < 0) return "Target can't be negative";
  if (num > 10) return "Target can't be above 10";
  return null;
}

function getRemainingError(value: string): string | null {
  if (value === '') return null;
  const num = parseFloat(value);
  if (isNaN(num)) return 'Enter a valid number';
  if (num === 0) return "Weight can't be zero";
  if (num < 0) return "Weight can't be negative";
  return null;
}

export function GradeCalculator() {
  const [grades, setGrades] = useState<GradeEntry[]>(INITIAL_GRADES);
  const [target, setTarget] = useState('');
  const [remainingWeight, setRemainingWeight] = useState('');
  const [confirmReset, setConfirmReset] = useState(false);

  const result = calculate(grades, target, remainingWeight);

  const targetError = getTargetError(target);
  const remainingError = getRemainingError(remainingWeight);

  const updateGrade = useCallback(
    (id: string, field: 'grade' | 'weight', value: string) => {
      setGrades((prev) =>
        prev.map((g) => (g.id === id ? { ...g, [field]: value } : g))
      );
    },
    []
  );

  const removeGrade = useCallback((id: string) => {
    setGrades((prev) =>
      prev.length > 1 ? prev.filter((g) => g.id !== id) : prev
    );
  }, []);

  const addGrade = useCallback(() => {
    setGrades((prev) => [...prev, createEmptyRow()]);
  }, []);

  const handleReset = () => {
    setGrades([createEmptyRow(), createEmptyRow()]);
    setTarget('');
    setRemainingWeight('');
    setConfirmReset(false);
  };

  return (
    <>
      <BackgroundNumbers />
      <div className="relative min-h-screen w-full flex items-start sm:items-center justify-center px-3 py-6 sm:px-4 sm:py-8">
        <main className="w-full max-w-2xl bg-brown-500 rounded-3xl shadow-2xl">
          {/* Header */}
          <div className="px-5 sm:px-8 pt-8 pb-6 text-center">
            <h1 className="font-display text-3xl sm:text-5xl font-bold text-cream-50 leading-tight">
              What Do I Need?
            </h1>
            <p className="mt-2 text-cream-100/80 text-sm sm:text-lg">
              Calculate what grade you need to reach your target.
            </p>
          </div>

          {/* Grade input section */}
          <div className="px-5 sm:px-8 space-y-3">
            <h2 className="text-cream-100/60 text-xs font-semibold uppercase tracking-wider">
              Your grades so far
            </h2>
            {grades.map((entry) => (
              <GradeRow
                key={entry.id}
                grade={entry.grade}
                weight={entry.weight}
                onChange={(field, value) =>
                  updateGrade(entry.id, field, value)
                }
                onRemove={() => removeGrade(entry.id)}
                canRemove={grades.length > 1}
              />
            ))}
            <button
              onClick={addGrade}
              className="w-full rounded-xl border-2 border-dashed border-cream-100/25 text-cream-100/80 py-3 hover:bg-cream-50/10 hover:border-cream-100/45 transition-colors flex items-center justify-center gap-2 font-medium focus:outline-none focus:ring-2 focus:ring-cream-100/30"
            >
              <Plus size={18} />
              Add grade
            </button>
          </div>

          {/* Divider */}
          <div className="px-5 sm:px-8 mt-6">
            <div className="h-px bg-cream-100/20" />
          </div>

          {/* Target & Remaining weight */}
          <div className="px-5 sm:px-8 mt-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div className="bg-cream-50 rounded-xl p-4 shadow-sm">
                <label className="block text-sm font-medium text-navy-500 mb-1">
                  Target final grade
                </label>
                <input
                  type="number"
                  inputMode="decimal"
                  step="0.1"
                  min="0"
                  max="10"
                  placeholder="e.g. 6.5"
                  value={target}
                  onChange={(e) => setTarget(e.target.value)}
                  className={`w-full rounded-lg border bg-white px-3 py-2.5 text-navy-700 text-lg font-medium focus:outline-none transition-colors ${
                    targetError
                      ? 'border-red-400 focus:border-red-500 focus:ring-2 focus:ring-red-500/20'
                      : 'border-beige-200 focus:border-brown-500 focus:ring-2 focus:ring-brown-500/20'
                  }`}
                  aria-label="Target final grade"
                  aria-invalid={targetError !== null}
                />
                <p className="mt-1 text-xs text-navy-500/60">
                  What do you want to finish with?
                </p>
                {targetError && (
                  <p className="mt-1 text-xs text-red-700" role="alert">
                    {targetError}
                  </p>
                )}
              </div>

              <div className="bg-cream-50 rounded-xl p-4 shadow-sm">
                <label className="block text-sm font-medium text-navy-500 mb-1">
                  Remaining assessment weight
                </label>
                <input
                  type="number"
                  inputMode="decimal"
                  step="0.5"
                  min="0"
                  placeholder="e.g. 1"
                  value={remainingWeight}
                  onChange={(e) => setRemainingWeight(e.target.value)}
                  className={`w-full rounded-lg border bg-white px-3 py-2.5 text-navy-700 text-lg font-medium focus:outline-none transition-colors ${
                    remainingError
                      ? 'border-red-400 focus:border-red-500 focus:ring-2 focus:ring-red-500/20'
                      : 'border-beige-200 focus:border-brown-500 focus:ring-2 focus:ring-brown-500/20'
                  }`}
                  aria-label="Remaining assessment weight"
                  aria-invalid={remainingError !== null}
                />
                <p className="mt-1 text-xs text-navy-500/60">
                  How much does your remaining assessment count?
                </p>
                {remainingError && (
                  <p className="mt-1 text-xs text-red-700" role="alert">
                    {remainingError}
                  </p>
                )}
              </div>
            </div>
          </div>

          {/* Result */}
          <div className="px-5 sm:px-8 mt-6">
            <ResultPanel result={result} />
          </div>

          {/* Stats */}
          <div className="px-5 sm:px-8 mt-4">
            <StatsPanel result={result} />
          </div>

          {/* Reset */}
          <div className="px-5 sm:px-8 mt-8 pb-8 flex justify-center">
            {confirmReset ? (
              <div className="w-full max-w-sm bg-beige-100 rounded-xl p-4 flex items-center gap-3 flex-wrap justify-center">
                <span className="text-navy-500 text-sm font-medium">
                  Reset everything?
                </span>
                <button
                  onClick={handleReset}
                  className="rounded-lg bg-brown-500 text-cream-50 px-4 py-2 text-sm font-semibold hover:bg-brown-600 transition-colors flex items-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-cream-100/50"
                >
                  <Check size={18} />
                  Yes, reset
                </button>
                <button
                  onClick={() => setConfirmReset(false)}
                  className="rounded-lg border border-navy-500/30 text-navy-500 px-4 py-2 text-sm font-semibold hover:bg-navy-500/10 transition-colors flex items-center gap-1.5 focus:outline-none focus:ring-2 focus:ring-navy-500/20"
                >
                  <X size={18} />
                  Cancel
                </button>
              </div>
            ) : (
              <button
                onClick={() => setConfirmReset(true)}
                className="w-full max-w-sm bg-beige-100 rounded-xl text-navy-500 px-4 py-3 text-base font-semibold hover:bg-beige-200 transition-colors flex items-center justify-center gap-2 focus:outline-none focus:ring-2 focus:ring-cream-100/30"
              >
                <RotateCcw size={20} />
                Start over
              </button>
            )}
          </div>
        </main>
      </div>
    </>
  );
}
