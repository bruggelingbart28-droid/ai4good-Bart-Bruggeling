import type { CalcResult } from '@/lib/types';
import { formatGrade } from '@/lib/calculations';

interface StatsPanelProps {
  result: CalcResult;
}

export function StatsPanel({ result }: StatsPanelProps) {
  const {
    currentAverage,
    maxFinalGrade,
    minFinalGrade,
    hasGrades,
    hasRemaining,
  } = result;

  const stats: { label: string; value: string; show: boolean }[] = [
    {
      label: 'Current average',
      value: currentAverage !== null ? formatGrade(currentAverage) : '—',
      show: hasGrades,
    },
    {
      label: 'Maximum possible grade',
      value: maxFinalGrade !== null ? formatGrade(maxFinalGrade) : '—',
      show: hasRemaining,
    },
    {
      label: 'Final grade with 0.00',
      value: minFinalGrade !== null ? formatGrade(minFinalGrade) : '—',
      show: hasRemaining,
    },
  ];

  const visibleStats = stats.filter((s) => s.show);

  if (visibleStats.length === 0) return null;

  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2.5">
      {visibleStats.map((stat) => (
        <div
          key={stat.label}
          className="rounded-xl bg-navy-500/10 border border-navy-500/10 p-3 text-center"
        >
          <p className="text-cream-100/60 text-[0.7rem] font-medium uppercase tracking-wide leading-tight">
            {stat.label}
          </p>
          <p className="font-display text-xl font-bold text-cream-50 mt-1">
            {stat.value}
          </p>
        </div>
      ))}
    </div>
  );
}
