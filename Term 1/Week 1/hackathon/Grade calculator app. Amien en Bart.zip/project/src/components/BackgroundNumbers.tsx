import { useMemo } from 'react';

const NUMBERS = [
  '1', '2', '3', '4', '5', '6', '7', '8', '9', '10',
  '6.5', '7.25', '8.5', '5.5', '9.0', '3.14', '4.2', '7.7',
];

interface DecorativeNumber {
  value: string;
  top: number;
  left: number;
  size: number;
  rotation: number;
  opacity: number;
}

function generateNumbers(count: number): DecorativeNumber[] {
  let seed = 42;
  const rand = () => {
    seed = (seed * 1103515245 + 12345) & 0x7fffffff;
    return seed / 0x7fffffff;
  };

  return Array.from({ length: count }, () => ({
    value: NUMBERS[Math.floor(rand() * NUMBERS.length)],
    top: rand() * 100,
    left: rand() * 100,
    size: 14 + rand() * 18,
    rotation: (rand() - 0.5) * 30,
    opacity: 0.10 + rand() * 0.12,
  }));
}

export function BackgroundNumbers() {
  const numbers = useMemo(() => generateNumbers(90), []);

  return (
    <div
      className="fixed inset-0 overflow-hidden pointer-events-none"
      aria-hidden="true"
    >
      {numbers.map((n, i) => (
        <span
          key={i}
          className="absolute font-display text-navy-500 select-none"
          style={{
            top: `${n.top}%`,
            left: `${n.left}%`,
            fontSize: `${n.size}px`,
            opacity: n.opacity,
            transform: `rotate(${n.rotation}deg)`,
          }}
        >
          {n.value}
        </span>
      ))}
    </div>
  );
}
