/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        beige: {
          50: '#F5EBDC',
          100: '#EDE0D0',
          200: '#E0D0BC',
          300: '#D4C2A8',
        },
        brown: {
          400: '#C77D32',
          500: '#B5651D',
          600: '#9E571A',
          700: '#874A16',
          800: '#6F3C12',
        },
        navy: {
          400: '#2A3A5C',
          500: '#1B2A4A',
          600: '#152039',
          700: '#101729',
        },
        cream: {
          50: '#FDF6EC',
          100: '#F9EDD8',
          200: '#F0E0C8',
        },
      },
      fontFamily: {
        display: ['"Fraunces"', 'serif'],
        sans: ['"Inter"', 'system-ui', 'sans-serif'],
      },
    },
  },
  plugins: [],
};
